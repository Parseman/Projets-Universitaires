const WEIGHTS ={
    GENRE : 3,
    ACTOR : 2,
    DIRECTOR : 8,
    KEYWORD : 1,
}

module.exports = WEIGHTS;

