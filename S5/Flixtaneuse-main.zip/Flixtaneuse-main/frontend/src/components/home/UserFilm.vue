<!-- 
    si l'utiilisateur est connecté on affiche ses films recommandés pour vous
-->
<template>



    <div>
      <h1>Films choisi pour vous</h1>
      <!-- Liste horizontale de films avec défilement -->
       <h2></h2>
       <div class="film-container">
        
  
        </div>
      <H2></H2>
        <div class="film-container">
  
        </div>
      
    </div>
  </template>