<!-- 
    Composant qui affiche les films de certains mots clé
    keywords = [
        "Extraterrestre",
        "Amitié",
        "Vengeance",
        "Français",
        "Voyage dans le temps",
        "Amour interdit",
        "Survie",
        "Trahison",
        "Esprit",
        "Guerre",
        "Héroïsme",
        "Immortalité",
        "Manipulation",
        "Sacrifice",
        "Liberté",
        "Cauchemar",
        "Découverte",
        "Destin",
        "Magie",
        "Secret"
    ]

-->
<template>



    <div>
      <h2>{{ keyword.nom }}</h2>
      <!-- Liste horizontale de films avec défilement -->
      <div class="film-container">
  
      </div>
  
    </div>
  </template>