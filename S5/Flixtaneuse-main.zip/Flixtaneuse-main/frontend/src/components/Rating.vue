<!-- 
    Composant qui gère la notation des films
-->