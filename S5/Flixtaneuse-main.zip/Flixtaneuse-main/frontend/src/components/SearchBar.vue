<!-- 
    Composant qui gère la barre de navigation 
-->