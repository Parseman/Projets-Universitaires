<?php
    /*
        N'ayant pas de fonctions à optimiser ,
        J'aimerai improvisé avec une fonction déjà optimisé avec une étude de sa complexité
    */

    // Version 1 (original)
    /*function action_changemdp(){
        $m = Model::getModel();
        if(isset($_POST["npass"]) && isset($_POST["cpass"])){ // isset
            if($_POST["npass"] == $_POST["cpass"]){
                $m->newmdp($_POST['id'],$_POST["npass"]);
                $this->render("login", ["message"=> "Le mot de passe a été modifié avec succés"]);
            }
        }
    }
        Complexité : O(n) car cette fonction dépend de la taille de la vue (voir fonction render() de Controller.php)
        Consommation mémoire : O(1)
    */

    // Version 2 (qui ne change en aucun cas la complexité & la consommation mémoire mais améliore la qualité du code)
    /*function action_changemdpv2(){
        $m = Model::getModel();
        if(isset($_POST["npass"]) && isset($_POST["cpass"]) && $_POST["npass"] == $_POST["cpass"]){
            $m->newmdp($_POST['id'],$_POST["npass"]);
            $this->render("login", ["message"=> "Le mot de passe a été modifié avec succés"]);
        }
    }
    
    */

?>