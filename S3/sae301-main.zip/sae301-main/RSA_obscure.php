<?php
    require __DIR__ . '/vendor/autoload.php';
    use phpseclib3\Crypt\RSA;

    function genRSAkeys(){
        $private = RSA::createKey();
        $public = $private->getPublicKey();
        return ['public' => $public, 'private' => $private];
    }

    function chiffrer($message, $public){
        return $public->encrypt($message);
    }

    function dechiffrer($message, $private){
        return $private->decrypt($message);
    }
?>