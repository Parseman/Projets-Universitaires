<?php
require 'Views/view_navbar.php';
require_once 'Utils/functions.php';
?>


<img src="Content/img/accueil_img.jpg" alt="" style="width: 100%;  top: 100px; position : relative;" >

<div style="color:#2388B0; padding:10px; text-align:right;">
        <h1 id="bottom">2023-2024 | Gosling © Tous droits réservés</h1>
    </div>
<?php require 'Views/view_end.php'; ?>