</div>
    <footer class="footer mt-auto py-3" style="background-color: #2388b0 !important;">
        <div class="container">
            <span class="text-muted" style="color: white !important;">© 2023/2024 Gosling</span>
        </div>
    </footer>
</body>
</html>