<?php
require_once 'Models/Model.php';

function e($message){
    return htmlspecialchars($message, ENT_QUOTES);
}

function isStringEmail($email){
    return preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/', $email);
}

function isLogged(){
    $m = Model::getModel();
    return (isset($_SESSION['logged']) && $m->isInDatabaseId(dechiffrer($_SESSION['logged']))) ? true : false;
}

function getCurrentRole(){
    $m = Model::getModel();
    return $m->getIdRole(dechiffrer($_SESSION['logged']));
}
?>