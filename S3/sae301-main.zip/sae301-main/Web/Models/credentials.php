<?php // Modifiez svp au lieu de dire que ca ne marche pas
// Et n'oubliez pas de créer une table administrateur qui hérite de personne
    $dsn = "pgsql:dbname=sae301;host=localhost"; // là
    $login = "omar"; // ici
    $mdp = "az7az9az8"; // et là aussi
?>

