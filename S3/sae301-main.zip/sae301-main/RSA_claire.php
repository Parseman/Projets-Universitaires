<?php

function isPrime($n) {
    if ($n < 2) {
        return false;
    }
    for ($i = 2; $i <= sqrt($n); $i++) {
        if ($n % $i == 0) {
            return false;
        }
    }
    return true;
}

function invmod($a, $mod) {
    $backupMod = $mod;
    $u = 0;
    $v = 1;
 
    if ($mod == 1)
        return 0;
 
    while ($a > 1) {
        $q = intval($a / $mod);
        $t = $mod;
 
        $mod = $a % $mod;
        $a = $t;
        $t = $u;
 
        $u = $v - $q * $u;
        $v = $t;
    }
 
    if ($v < 0)
        $v += $backupMod;
 
    return $v;
}

function randPrime() {
    $p = rand(10000, 1000000);
    while (!isPrime($p)){
        $p = rand(10000, 1000000);
    };
    return $p;
}

function pgcd($a, $b) {
    if ($b == 0) {
        return $a;
    }
    return pgcd($b, $a % $b);
}

function genCleRSA($p = -1, $q = -1) {
    if($p == -1){
        $p = randPrime();
    }
    if($q == -1){
        $q = randPrime();
    }
    $n = $p * $q;
    $phi = ($p - 1) * ($q - 1);
    $e = rand(2, $phi);
    while (pgcd($e, $phi) != 1){
        $e = rand(2, $phi);
    }

    $d = invmod($e, $phi);

    return ['public' => [$n, $e], 'private' => [$n, $d]];
}

function chiffrer($msg, $clePub) {
    $string = "";
    $e = $clePub[1];
    $n = $clePub[0];
    foreach(str_split($msg) as $i => $char){
        $x = ord($char);
        $crypt_x = bcpowmod($x, $e, $n);
        $string = $string . strval($crypt_x) . "-";
    }
    return substr($string,0,-1);
}

function dechiffrer($msgCryptee, $clePriv) {
    $string = "";
    $d = $clePriv[1];
    $n = $clePriv[0];
    foreach(explode('-', $msgCryptee) as $i => $code){
        $x = (int)$code;
        $decrypt_x = bcpowmod($x, $d, $n);
        $string = $string . chr($decrypt_x);
    }
    return $string;
}

$keys = genCleRSA();
$msg = "Hello";
$cryptee = chiffrer($msg, $keys['public']);
$newMessage = dechiffrer($cryptee, $keys['private']);

echo "Message: " . $msg . nl2br("\n");
echo "Message crypté: " . $cryptee . nl2br("\n");
echo "Message décrypté: " . $newMessage . nl2br("\n");

?>